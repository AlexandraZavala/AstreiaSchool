﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AstreiaSoft
{
    public enum Estado
    {
        Inicial, Nuevo, Buscar, Editar, Seleccionar, Eliminar, Guardar, Cancelar, Existe
    }
}
