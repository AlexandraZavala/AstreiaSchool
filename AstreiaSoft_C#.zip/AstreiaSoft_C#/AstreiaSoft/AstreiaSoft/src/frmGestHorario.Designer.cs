﻿namespace WindowsFormsApp1
{
    partial class frmGestHorario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboDocente = new System.Windows.Forms.ComboBox();
            this.cboCurso = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cboGrado = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboSeccion = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btn_V_17_18 = new System.Windows.Forms.Button();
            this.btn_J_17_18 = new System.Windows.Forms.Button();
            this.btn_X_17_18 = new System.Windows.Forms.Button();
            this.btn_M_17_18 = new System.Windows.Forms.Button();
            this.btn_L_17_18 = new System.Windows.Forms.Button();
            this.btn_V_16_17 = new System.Windows.Forms.Button();
            this.btn_J_16_17 = new System.Windows.Forms.Button();
            this.btn_X_16_17 = new System.Windows.Forms.Button();
            this.btn_M_16_17 = new System.Windows.Forms.Button();
            this.btn_L_16_17 = new System.Windows.Forms.Button();
            this.btn_V_15_16 = new System.Windows.Forms.Button();
            this.btn_J_15_16 = new System.Windows.Forms.Button();
            this.btn_X_15_16 = new System.Windows.Forms.Button();
            this.btn_M_15_16 = new System.Windows.Forms.Button();
            this.btn_L_15_16 = new System.Windows.Forms.Button();
            this.btn_V_13_14 = new System.Windows.Forms.Button();
            this.btn_J_13_14 = new System.Windows.Forms.Button();
            this.btn_X_13_14 = new System.Windows.Forms.Button();
            this.btn_M_13_14 = new System.Windows.Forms.Button();
            this.btn_L_13_14 = new System.Windows.Forms.Button();
            this.btn_V_12_13 = new System.Windows.Forms.Button();
            this.btn_J_12_13 = new System.Windows.Forms.Button();
            this.btn_X_12_13 = new System.Windows.Forms.Button();
            this.btn_M_12_13 = new System.Windows.Forms.Button();
            this.btn_L_12_13 = new System.Windows.Forms.Button();
            this.btn_V_11_12 = new System.Windows.Forms.Button();
            this.btn_J_11_12 = new System.Windows.Forms.Button();
            this.btn_X_11_12 = new System.Windows.Forms.Button();
            this.btn_M_11_12 = new System.Windows.Forms.Button();
            this.btn_L_11_12 = new System.Windows.Forms.Button();
            this.btn_V_10_11 = new System.Windows.Forms.Button();
            this.btn_J_10_11 = new System.Windows.Forms.Button();
            this.btn_X_10_11 = new System.Windows.Forms.Button();
            this.btn_M_10_11 = new System.Windows.Forms.Button();
            this.btn_L_10_11 = new System.Windows.Forms.Button();
            this.btn_V_9_10 = new System.Windows.Forms.Button();
            this.btn_J_9_10 = new System.Windows.Forms.Button();
            this.btn_X_9_10 = new System.Windows.Forms.Button();
            this.btn_M_9_10 = new System.Windows.Forms.Button();
            this.btn_L_9_10 = new System.Windows.Forms.Button();
            this.btn_V_8_9 = new System.Windows.Forms.Button();
            this.btn_J_8_9 = new System.Windows.Forms.Button();
            this.btn_X_8_9 = new System.Windows.Forms.Button();
            this.btn_M_8_9 = new System.Windows.Forms.Button();
            this.btn_L_8_9 = new System.Windows.Forms.Button();
            this.btn_V_14_15 = new System.Windows.Forms.Button();
            this.btn_J_14_15 = new System.Windows.Forms.Button();
            this.btn_X_14_15 = new System.Windows.Forms.Button();
            this.btn_M_14_15 = new System.Windows.Forms.Button();
            this.btn_L_14_15 = new System.Windows.Forms.Button();
            this.pbHorario = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHorario)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboDocente);
            this.groupBox1.Controls.Add(this.cboCurso);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cboGrado);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cboSeccion);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(56, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(694, 138);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Horario";
            // 
            // cboDocente
            // 
            this.cboDocente.FormattingEnabled = true;
            this.cboDocente.Location = new System.Drawing.Point(163, 102);
            this.cboDocente.Name = "cboDocente";
            this.cboDocente.Size = new System.Drawing.Size(365, 24);
            this.cboDocente.TabIndex = 18;
            // 
            // cboCurso
            // 
            this.cboCurso.FormattingEnabled = true;
            this.cboCurso.Location = new System.Drawing.Point(161, 64);
            this.cboCurso.Name = "cboCurso";
            this.cboCurso.Size = new System.Drawing.Size(368, 24);
            this.cboCurso.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 16;
            this.label3.Text = "Grado:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Docente:";
            // 
            // cboGrado
            // 
            this.cboGrado.FormattingEnabled = true;
            this.cboGrado.Location = new System.Drawing.Point(161, 24);
            this.cboGrado.Name = "cboGrado";
            this.cboGrado.Size = new System.Drawing.Size(163, 24);
            this.cboGrado.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Curso:";
            // 
            // cboSeccion
            // 
            this.cboSeccion.FormattingEnabled = true;
            this.cboSeccion.Location = new System.Drawing.Point(420, 24);
            this.cboSeccion.Name = "cboSeccion";
            this.cboSeccion.Size = new System.Drawing.Size(191, 24);
            this.cboSeccion.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(351, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "Sección:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.Transparent;
            this.btnCancelar.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Image = global::AstreiaSoft.Properties.Resources.img_cancelar_17;
            this.btnCancelar.Location = new System.Drawing.Point(517, 25);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(105, 32);
            this.btnCancelar.TabIndex = 30;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.BackColor = System.Drawing.Color.Transparent;
            this.btnNuevo.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevo.Image = global::AstreiaSoft.Properties.Resources.img_nuevo_17;
            this.btnNuevo.Location = new System.Drawing.Point(189, 25);
            this.btnNuevo.Margin = new System.Windows.Forms.Padding(2);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(105, 32);
            this.btnNuevo.TabIndex = 29;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNuevo.UseVisualStyleBackColor = false;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.Transparent;
            this.btnEliminar.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.Image = global::AstreiaSoft.Properties.Resources.img_eliminar_17;
            this.btnEliminar.Location = new System.Drawing.Point(407, 25);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(2);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(105, 32);
            this.btnEliminar.TabIndex = 28;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.Transparent;
            this.btnGuardar.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.Image = global::AstreiaSoft.Properties.Resources.img_guardar_17;
            this.btnGuardar.Location = new System.Drawing.Point(298, 25);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(2);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(105, 32);
            this.btnGuardar.TabIndex = 26;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btn_V_17_18
            // 
            this.btn_V_17_18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_17_18.Location = new System.Drawing.Point(637, 589);
            this.btn_V_17_18.Name = "btn_V_17_18";
            this.btn_V_17_18.Size = new System.Drawing.Size(131, 36);
            this.btn_V_17_18.TabIndex = 144;
            this.btn_V_17_18.UseVisualStyleBackColor = false;
            // 
            // btn_J_17_18
            // 
            this.btn_J_17_18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_17_18.Location = new System.Drawing.Point(507, 589);
            this.btn_J_17_18.Name = "btn_J_17_18";
            this.btn_J_17_18.Size = new System.Drawing.Size(131, 36);
            this.btn_J_17_18.TabIndex = 143;
            this.btn_J_17_18.UseVisualStyleBackColor = false;
            // 
            // btn_X_17_18
            // 
            this.btn_X_17_18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_17_18.Location = new System.Drawing.Point(377, 589);
            this.btn_X_17_18.Name = "btn_X_17_18";
            this.btn_X_17_18.Size = new System.Drawing.Size(131, 36);
            this.btn_X_17_18.TabIndex = 142;
            this.btn_X_17_18.UseVisualStyleBackColor = false;
            // 
            // btn_M_17_18
            // 
            this.btn_M_17_18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_17_18.Location = new System.Drawing.Point(247, 589);
            this.btn_M_17_18.Name = "btn_M_17_18";
            this.btn_M_17_18.Size = new System.Drawing.Size(131, 36);
            this.btn_M_17_18.TabIndex = 141;
            this.btn_M_17_18.UseVisualStyleBackColor = false;
            // 
            // btn_L_17_18
            // 
            this.btn_L_17_18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_17_18.Location = new System.Drawing.Point(117, 589);
            this.btn_L_17_18.Name = "btn_L_17_18";
            this.btn_L_17_18.Size = new System.Drawing.Size(131, 36);
            this.btn_L_17_18.TabIndex = 140;
            this.btn_L_17_18.UseVisualStyleBackColor = false;
            // 
            // btn_V_16_17
            // 
            this.btn_V_16_17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_16_17.Location = new System.Drawing.Point(637, 552);
            this.btn_V_16_17.Name = "btn_V_16_17";
            this.btn_V_16_17.Size = new System.Drawing.Size(131, 36);
            this.btn_V_16_17.TabIndex = 139;
            this.btn_V_16_17.UseVisualStyleBackColor = false;
            // 
            // btn_J_16_17
            // 
            this.btn_J_16_17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_16_17.Location = new System.Drawing.Point(507, 552);
            this.btn_J_16_17.Name = "btn_J_16_17";
            this.btn_J_16_17.Size = new System.Drawing.Size(131, 36);
            this.btn_J_16_17.TabIndex = 138;
            this.btn_J_16_17.UseVisualStyleBackColor = false;
            // 
            // btn_X_16_17
            // 
            this.btn_X_16_17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_16_17.Location = new System.Drawing.Point(377, 552);
            this.btn_X_16_17.Name = "btn_X_16_17";
            this.btn_X_16_17.Size = new System.Drawing.Size(131, 36);
            this.btn_X_16_17.TabIndex = 137;
            this.btn_X_16_17.UseVisualStyleBackColor = false;
            // 
            // btn_M_16_17
            // 
            this.btn_M_16_17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_16_17.Location = new System.Drawing.Point(247, 552);
            this.btn_M_16_17.Name = "btn_M_16_17";
            this.btn_M_16_17.Size = new System.Drawing.Size(131, 36);
            this.btn_M_16_17.TabIndex = 136;
            this.btn_M_16_17.UseVisualStyleBackColor = false;
            // 
            // btn_L_16_17
            // 
            this.btn_L_16_17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_16_17.Location = new System.Drawing.Point(117, 552);
            this.btn_L_16_17.Name = "btn_L_16_17";
            this.btn_L_16_17.Size = new System.Drawing.Size(131, 36);
            this.btn_L_16_17.TabIndex = 135;
            this.btn_L_16_17.UseVisualStyleBackColor = false;
            // 
            // btn_V_15_16
            // 
            this.btn_V_15_16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_15_16.Location = new System.Drawing.Point(637, 515);
            this.btn_V_15_16.Name = "btn_V_15_16";
            this.btn_V_15_16.Size = new System.Drawing.Size(131, 36);
            this.btn_V_15_16.TabIndex = 134;
            this.btn_V_15_16.UseVisualStyleBackColor = false;
            // 
            // btn_J_15_16
            // 
            this.btn_J_15_16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_15_16.Location = new System.Drawing.Point(507, 515);
            this.btn_J_15_16.Name = "btn_J_15_16";
            this.btn_J_15_16.Size = new System.Drawing.Size(131, 36);
            this.btn_J_15_16.TabIndex = 133;
            this.btn_J_15_16.UseVisualStyleBackColor = false;
            // 
            // btn_X_15_16
            // 
            this.btn_X_15_16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_15_16.Location = new System.Drawing.Point(377, 515);
            this.btn_X_15_16.Name = "btn_X_15_16";
            this.btn_X_15_16.Size = new System.Drawing.Size(131, 36);
            this.btn_X_15_16.TabIndex = 132;
            this.btn_X_15_16.UseVisualStyleBackColor = false;
            // 
            // btn_M_15_16
            // 
            this.btn_M_15_16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_15_16.Location = new System.Drawing.Point(247, 515);
            this.btn_M_15_16.Name = "btn_M_15_16";
            this.btn_M_15_16.Size = new System.Drawing.Size(131, 36);
            this.btn_M_15_16.TabIndex = 131;
            this.btn_M_15_16.UseVisualStyleBackColor = false;
            // 
            // btn_L_15_16
            // 
            this.btn_L_15_16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_15_16.Location = new System.Drawing.Point(117, 515);
            this.btn_L_15_16.Name = "btn_L_15_16";
            this.btn_L_15_16.Size = new System.Drawing.Size(131, 36);
            this.btn_L_15_16.TabIndex = 130;
            this.btn_L_15_16.UseVisualStyleBackColor = false;
            // 
            // btn_V_13_14
            // 
            this.btn_V_13_14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_13_14.Location = new System.Drawing.Point(637, 443);
            this.btn_V_13_14.Name = "btn_V_13_14";
            this.btn_V_13_14.Size = new System.Drawing.Size(131, 36);
            this.btn_V_13_14.TabIndex = 129;
            this.btn_V_13_14.UseVisualStyleBackColor = false;
            // 
            // btn_J_13_14
            // 
            this.btn_J_13_14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_13_14.Location = new System.Drawing.Point(507, 443);
            this.btn_J_13_14.Name = "btn_J_13_14";
            this.btn_J_13_14.Size = new System.Drawing.Size(131, 36);
            this.btn_J_13_14.TabIndex = 128;
            this.btn_J_13_14.UseVisualStyleBackColor = false;
            // 
            // btn_X_13_14
            // 
            this.btn_X_13_14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_13_14.Location = new System.Drawing.Point(377, 443);
            this.btn_X_13_14.Name = "btn_X_13_14";
            this.btn_X_13_14.Size = new System.Drawing.Size(131, 36);
            this.btn_X_13_14.TabIndex = 127;
            this.btn_X_13_14.UseVisualStyleBackColor = false;
            // 
            // btn_M_13_14
            // 
            this.btn_M_13_14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_13_14.Location = new System.Drawing.Point(247, 443);
            this.btn_M_13_14.Name = "btn_M_13_14";
            this.btn_M_13_14.Size = new System.Drawing.Size(131, 36);
            this.btn_M_13_14.TabIndex = 126;
            this.btn_M_13_14.UseVisualStyleBackColor = false;
            // 
            // btn_L_13_14
            // 
            this.btn_L_13_14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_13_14.Location = new System.Drawing.Point(117, 443);
            this.btn_L_13_14.Name = "btn_L_13_14";
            this.btn_L_13_14.Size = new System.Drawing.Size(131, 36);
            this.btn_L_13_14.TabIndex = 125;
            this.btn_L_13_14.UseVisualStyleBackColor = false;
            // 
            // btn_V_12_13
            // 
            this.btn_V_12_13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_12_13.Location = new System.Drawing.Point(637, 406);
            this.btn_V_12_13.Name = "btn_V_12_13";
            this.btn_V_12_13.Size = new System.Drawing.Size(131, 36);
            this.btn_V_12_13.TabIndex = 124;
            this.btn_V_12_13.UseVisualStyleBackColor = false;
            // 
            // btn_J_12_13
            // 
            this.btn_J_12_13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_12_13.Location = new System.Drawing.Point(507, 406);
            this.btn_J_12_13.Name = "btn_J_12_13";
            this.btn_J_12_13.Size = new System.Drawing.Size(131, 36);
            this.btn_J_12_13.TabIndex = 123;
            this.btn_J_12_13.UseVisualStyleBackColor = false;
            // 
            // btn_X_12_13
            // 
            this.btn_X_12_13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_12_13.Location = new System.Drawing.Point(377, 406);
            this.btn_X_12_13.Name = "btn_X_12_13";
            this.btn_X_12_13.Size = new System.Drawing.Size(131, 36);
            this.btn_X_12_13.TabIndex = 122;
            this.btn_X_12_13.UseVisualStyleBackColor = false;
            // 
            // btn_M_12_13
            // 
            this.btn_M_12_13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_12_13.Location = new System.Drawing.Point(247, 406);
            this.btn_M_12_13.Name = "btn_M_12_13";
            this.btn_M_12_13.Size = new System.Drawing.Size(131, 36);
            this.btn_M_12_13.TabIndex = 121;
            this.btn_M_12_13.UseVisualStyleBackColor = false;
            // 
            // btn_L_12_13
            // 
            this.btn_L_12_13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_12_13.Location = new System.Drawing.Point(117, 406);
            this.btn_L_12_13.Name = "btn_L_12_13";
            this.btn_L_12_13.Size = new System.Drawing.Size(131, 36);
            this.btn_L_12_13.TabIndex = 120;
            this.btn_L_12_13.UseVisualStyleBackColor = false;
            // 
            // btn_V_11_12
            // 
            this.btn_V_11_12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_11_12.Location = new System.Drawing.Point(637, 369);
            this.btn_V_11_12.Name = "btn_V_11_12";
            this.btn_V_11_12.Size = new System.Drawing.Size(131, 36);
            this.btn_V_11_12.TabIndex = 119;
            this.btn_V_11_12.UseVisualStyleBackColor = false;
            // 
            // btn_J_11_12
            // 
            this.btn_J_11_12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_11_12.Location = new System.Drawing.Point(507, 369);
            this.btn_J_11_12.Name = "btn_J_11_12";
            this.btn_J_11_12.Size = new System.Drawing.Size(131, 36);
            this.btn_J_11_12.TabIndex = 118;
            this.btn_J_11_12.UseVisualStyleBackColor = false;
            // 
            // btn_X_11_12
            // 
            this.btn_X_11_12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_11_12.Location = new System.Drawing.Point(377, 369);
            this.btn_X_11_12.Name = "btn_X_11_12";
            this.btn_X_11_12.Size = new System.Drawing.Size(131, 36);
            this.btn_X_11_12.TabIndex = 117;
            this.btn_X_11_12.UseVisualStyleBackColor = false;
            // 
            // btn_M_11_12
            // 
            this.btn_M_11_12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_11_12.Location = new System.Drawing.Point(247, 369);
            this.btn_M_11_12.Name = "btn_M_11_12";
            this.btn_M_11_12.Size = new System.Drawing.Size(131, 36);
            this.btn_M_11_12.TabIndex = 116;
            this.btn_M_11_12.UseVisualStyleBackColor = false;
            // 
            // btn_L_11_12
            // 
            this.btn_L_11_12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_11_12.Location = new System.Drawing.Point(117, 369);
            this.btn_L_11_12.Name = "btn_L_11_12";
            this.btn_L_11_12.Size = new System.Drawing.Size(131, 36);
            this.btn_L_11_12.TabIndex = 115;
            this.btn_L_11_12.UseVisualStyleBackColor = false;
            // 
            // btn_V_10_11
            // 
            this.btn_V_10_11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_10_11.Location = new System.Drawing.Point(637, 332);
            this.btn_V_10_11.Name = "btn_V_10_11";
            this.btn_V_10_11.Size = new System.Drawing.Size(131, 36);
            this.btn_V_10_11.TabIndex = 114;
            this.btn_V_10_11.UseVisualStyleBackColor = false;
            // 
            // btn_J_10_11
            // 
            this.btn_J_10_11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_10_11.Location = new System.Drawing.Point(507, 332);
            this.btn_J_10_11.Name = "btn_J_10_11";
            this.btn_J_10_11.Size = new System.Drawing.Size(131, 36);
            this.btn_J_10_11.TabIndex = 113;
            this.btn_J_10_11.UseVisualStyleBackColor = false;
            // 
            // btn_X_10_11
            // 
            this.btn_X_10_11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_10_11.Location = new System.Drawing.Point(377, 332);
            this.btn_X_10_11.Name = "btn_X_10_11";
            this.btn_X_10_11.Size = new System.Drawing.Size(131, 36);
            this.btn_X_10_11.TabIndex = 112;
            this.btn_X_10_11.UseVisualStyleBackColor = false;
            // 
            // btn_M_10_11
            // 
            this.btn_M_10_11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_10_11.Location = new System.Drawing.Point(247, 332);
            this.btn_M_10_11.Name = "btn_M_10_11";
            this.btn_M_10_11.Size = new System.Drawing.Size(131, 36);
            this.btn_M_10_11.TabIndex = 111;
            this.btn_M_10_11.UseVisualStyleBackColor = false;
            // 
            // btn_L_10_11
            // 
            this.btn_L_10_11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_10_11.Location = new System.Drawing.Point(117, 332);
            this.btn_L_10_11.Name = "btn_L_10_11";
            this.btn_L_10_11.Size = new System.Drawing.Size(131, 36);
            this.btn_L_10_11.TabIndex = 110;
            this.btn_L_10_11.UseVisualStyleBackColor = false;
            // 
            // btn_V_9_10
            // 
            this.btn_V_9_10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_9_10.Location = new System.Drawing.Point(637, 295);
            this.btn_V_9_10.Name = "btn_V_9_10";
            this.btn_V_9_10.Size = new System.Drawing.Size(131, 36);
            this.btn_V_9_10.TabIndex = 109;
            this.btn_V_9_10.UseVisualStyleBackColor = false;
            // 
            // btn_J_9_10
            // 
            this.btn_J_9_10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_9_10.Location = new System.Drawing.Point(507, 295);
            this.btn_J_9_10.Name = "btn_J_9_10";
            this.btn_J_9_10.Size = new System.Drawing.Size(131, 36);
            this.btn_J_9_10.TabIndex = 108;
            this.btn_J_9_10.UseVisualStyleBackColor = false;
            // 
            // btn_X_9_10
            // 
            this.btn_X_9_10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_9_10.Location = new System.Drawing.Point(377, 295);
            this.btn_X_9_10.Name = "btn_X_9_10";
            this.btn_X_9_10.Size = new System.Drawing.Size(131, 36);
            this.btn_X_9_10.TabIndex = 107;
            this.btn_X_9_10.UseVisualStyleBackColor = false;
            // 
            // btn_M_9_10
            // 
            this.btn_M_9_10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_9_10.Location = new System.Drawing.Point(247, 295);
            this.btn_M_9_10.Name = "btn_M_9_10";
            this.btn_M_9_10.Size = new System.Drawing.Size(131, 36);
            this.btn_M_9_10.TabIndex = 106;
            this.btn_M_9_10.UseVisualStyleBackColor = false;
            // 
            // btn_L_9_10
            // 
            this.btn_L_9_10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_9_10.Location = new System.Drawing.Point(117, 295);
            this.btn_L_9_10.Name = "btn_L_9_10";
            this.btn_L_9_10.Size = new System.Drawing.Size(131, 36);
            this.btn_L_9_10.TabIndex = 105;
            this.btn_L_9_10.UseVisualStyleBackColor = false;
            // 
            // btn_V_8_9
            // 
            this.btn_V_8_9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_8_9.Location = new System.Drawing.Point(637, 258);
            this.btn_V_8_9.Name = "btn_V_8_9";
            this.btn_V_8_9.Size = new System.Drawing.Size(131, 36);
            this.btn_V_8_9.TabIndex = 104;
            this.btn_V_8_9.UseVisualStyleBackColor = false;
            // 
            // btn_J_8_9
            // 
            this.btn_J_8_9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_8_9.Location = new System.Drawing.Point(507, 258);
            this.btn_J_8_9.Name = "btn_J_8_9";
            this.btn_J_8_9.Size = new System.Drawing.Size(131, 36);
            this.btn_J_8_9.TabIndex = 103;
            this.btn_J_8_9.UseVisualStyleBackColor = false;
            // 
            // btn_X_8_9
            // 
            this.btn_X_8_9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_8_9.Location = new System.Drawing.Point(377, 258);
            this.btn_X_8_9.Name = "btn_X_8_9";
            this.btn_X_8_9.Size = new System.Drawing.Size(131, 36);
            this.btn_X_8_9.TabIndex = 102;
            this.btn_X_8_9.UseVisualStyleBackColor = false;
            // 
            // btn_M_8_9
            // 
            this.btn_M_8_9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_8_9.Location = new System.Drawing.Point(247, 258);
            this.btn_M_8_9.Name = "btn_M_8_9";
            this.btn_M_8_9.Size = new System.Drawing.Size(131, 36);
            this.btn_M_8_9.TabIndex = 101;
            this.btn_M_8_9.UseVisualStyleBackColor = false;
            // 
            // btn_L_8_9
            // 
            this.btn_L_8_9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_8_9.Location = new System.Drawing.Point(117, 258);
            this.btn_L_8_9.Name = "btn_L_8_9";
            this.btn_L_8_9.Size = new System.Drawing.Size(131, 36);
            this.btn_L_8_9.TabIndex = 100;
            this.btn_L_8_9.UseVisualStyleBackColor = false;
            // 
            // btn_V_14_15
            // 
            this.btn_V_14_15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_V_14_15.Location = new System.Drawing.Point(637, 479);
            this.btn_V_14_15.Name = "btn_V_14_15";
            this.btn_V_14_15.Size = new System.Drawing.Size(131, 36);
            this.btn_V_14_15.TabIndex = 97;
            this.btn_V_14_15.UseVisualStyleBackColor = false;
            // 
            // btn_J_14_15
            // 
            this.btn_J_14_15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_J_14_15.Location = new System.Drawing.Point(507, 479);
            this.btn_J_14_15.Name = "btn_J_14_15";
            this.btn_J_14_15.Size = new System.Drawing.Size(131, 36);
            this.btn_J_14_15.TabIndex = 96;
            this.btn_J_14_15.UseVisualStyleBackColor = false;
            // 
            // btn_X_14_15
            // 
            this.btn_X_14_15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_X_14_15.Location = new System.Drawing.Point(377, 479);
            this.btn_X_14_15.Name = "btn_X_14_15";
            this.btn_X_14_15.Size = new System.Drawing.Size(131, 36);
            this.btn_X_14_15.TabIndex = 95;
            this.btn_X_14_15.UseVisualStyleBackColor = false;
            // 
            // btn_M_14_15
            // 
            this.btn_M_14_15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_M_14_15.Location = new System.Drawing.Point(247, 479);
            this.btn_M_14_15.Name = "btn_M_14_15";
            this.btn_M_14_15.Size = new System.Drawing.Size(131, 36);
            this.btn_M_14_15.TabIndex = 94;
            this.btn_M_14_15.UseVisualStyleBackColor = false;
            // 
            // btn_L_14_15
            // 
            this.btn_L_14_15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_L_14_15.Location = new System.Drawing.Point(117, 479);
            this.btn_L_14_15.Name = "btn_L_14_15";
            this.btn_L_14_15.Size = new System.Drawing.Size(131, 36);
            this.btn_L_14_15.TabIndex = 93;
            this.btn_L_14_15.UseVisualStyleBackColor = false;
            // 
            // pbHorario
            // 
            this.pbHorario.Image = global::AstreiaSoft.Properties.Resources.imagenHorario;
            this.pbHorario.Location = new System.Drawing.Point(30, 216);
            this.pbHorario.Name = "pbHorario";
            this.pbHorario.Size = new System.Drawing.Size(748, 420);
            this.pbHorario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbHorario.TabIndex = 98;
            this.pbHorario.TabStop = false;
            // 
            // frmGestHorario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(800, 697);
            this.Controls.Add(this.btn_V_17_18);
            this.Controls.Add(this.btn_J_17_18);
            this.Controls.Add(this.btn_X_17_18);
            this.Controls.Add(this.btn_M_17_18);
            this.Controls.Add(this.btn_L_17_18);
            this.Controls.Add(this.btn_V_16_17);
            this.Controls.Add(this.btn_J_16_17);
            this.Controls.Add(this.btn_X_16_17);
            this.Controls.Add(this.btn_M_16_17);
            this.Controls.Add(this.btn_L_16_17);
            this.Controls.Add(this.btn_V_15_16);
            this.Controls.Add(this.btn_J_15_16);
            this.Controls.Add(this.btn_X_15_16);
            this.Controls.Add(this.btn_M_15_16);
            this.Controls.Add(this.btn_L_15_16);
            this.Controls.Add(this.btn_V_13_14);
            this.Controls.Add(this.btn_J_13_14);
            this.Controls.Add(this.btn_X_13_14);
            this.Controls.Add(this.btn_M_13_14);
            this.Controls.Add(this.btn_L_13_14);
            this.Controls.Add(this.btn_V_12_13);
            this.Controls.Add(this.btn_J_12_13);
            this.Controls.Add(this.btn_X_12_13);
            this.Controls.Add(this.btn_M_12_13);
            this.Controls.Add(this.btn_L_12_13);
            this.Controls.Add(this.btn_V_11_12);
            this.Controls.Add(this.btn_J_11_12);
            this.Controls.Add(this.btn_X_11_12);
            this.Controls.Add(this.btn_M_11_12);
            this.Controls.Add(this.btn_L_11_12);
            this.Controls.Add(this.btn_V_10_11);
            this.Controls.Add(this.btn_J_10_11);
            this.Controls.Add(this.btn_X_10_11);
            this.Controls.Add(this.btn_M_10_11);
            this.Controls.Add(this.btn_L_10_11);
            this.Controls.Add(this.btn_V_9_10);
            this.Controls.Add(this.btn_J_9_10);
            this.Controls.Add(this.btn_X_9_10);
            this.Controls.Add(this.btn_M_9_10);
            this.Controls.Add(this.btn_L_9_10);
            this.Controls.Add(this.btn_V_8_9);
            this.Controls.Add(this.btn_J_8_9);
            this.Controls.Add(this.btn_X_8_9);
            this.Controls.Add(this.btn_M_8_9);
            this.Controls.Add(this.btn_L_8_9);
            this.Controls.Add(this.btn_V_14_15);
            this.Controls.Add(this.btn_J_14_15);
            this.Controls.Add(this.btn_X_14_15);
            this.Controls.Add(this.btn_M_14_15);
            this.Controls.Add(this.btn_L_14_15);
            this.Controls.Add(this.pbHorario);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnNuevo);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmGestHorario";
            this.Text = "frmGestHorario";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHorario)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboCurso;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboSeccion;
        private System.Windows.Forms.ComboBox cboGrado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btn_V_17_18;
        private System.Windows.Forms.Button btn_J_17_18;
        private System.Windows.Forms.Button btn_X_17_18;
        private System.Windows.Forms.Button btn_M_17_18;
        private System.Windows.Forms.Button btn_L_17_18;
        private System.Windows.Forms.Button btn_V_16_17;
        private System.Windows.Forms.Button btn_J_16_17;
        private System.Windows.Forms.Button btn_X_16_17;
        private System.Windows.Forms.Button btn_M_16_17;
        private System.Windows.Forms.Button btn_L_16_17;
        private System.Windows.Forms.Button btn_V_15_16;
        private System.Windows.Forms.Button btn_J_15_16;
        private System.Windows.Forms.Button btn_X_15_16;
        private System.Windows.Forms.Button btn_M_15_16;
        private System.Windows.Forms.Button btn_L_15_16;
        private System.Windows.Forms.Button btn_V_13_14;
        private System.Windows.Forms.Button btn_J_13_14;
        private System.Windows.Forms.Button btn_X_13_14;
        private System.Windows.Forms.Button btn_M_13_14;
        private System.Windows.Forms.Button btn_L_13_14;
        private System.Windows.Forms.Button btn_V_12_13;
        private System.Windows.Forms.Button btn_J_12_13;
        private System.Windows.Forms.Button btn_X_12_13;
        private System.Windows.Forms.Button btn_M_12_13;
        private System.Windows.Forms.Button btn_L_12_13;
        private System.Windows.Forms.Button btn_V_11_12;
        private System.Windows.Forms.Button btn_J_11_12;
        private System.Windows.Forms.Button btn_X_11_12;
        private System.Windows.Forms.Button btn_M_11_12;
        private System.Windows.Forms.Button btn_L_11_12;
        private System.Windows.Forms.Button btn_V_10_11;
        private System.Windows.Forms.Button btn_J_10_11;
        private System.Windows.Forms.Button btn_X_10_11;
        private System.Windows.Forms.Button btn_M_10_11;
        private System.Windows.Forms.Button btn_L_10_11;
        private System.Windows.Forms.Button btn_V_9_10;
        private System.Windows.Forms.Button btn_J_9_10;
        private System.Windows.Forms.Button btn_X_9_10;
        private System.Windows.Forms.Button btn_M_9_10;
        private System.Windows.Forms.Button btn_L_9_10;
        private System.Windows.Forms.Button btn_V_8_9;
        private System.Windows.Forms.Button btn_J_8_9;
        private System.Windows.Forms.Button btn_X_8_9;
        private System.Windows.Forms.Button btn_M_8_9;
        private System.Windows.Forms.Button btn_L_8_9;
        private System.Windows.Forms.Button btn_V_14_15;
        private System.Windows.Forms.Button btn_J_14_15;
        private System.Windows.Forms.Button btn_X_14_15;
        private System.Windows.Forms.Button btn_M_14_15;
        private System.Windows.Forms.Button btn_L_14_15;
        private System.Windows.Forms.PictureBox pbHorario;
        private System.Windows.Forms.ComboBox cboDocente;
    }
}