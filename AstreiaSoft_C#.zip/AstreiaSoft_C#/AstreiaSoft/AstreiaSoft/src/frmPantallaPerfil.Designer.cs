﻿namespace AstreiaSoft
{
    partial class frmPantallaPerfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCorreoPerfil = new System.Windows.Forms.TextBox();
            this.txtNombrePerfil = new System.Windows.Forms.TextBox();
            this.txtDireccionPerfil = new System.Windows.Forms.TextBox();
            this.txtTelefonoPerfil = new System.Windows.Forms.TextBox();
            this.txtFechaNacimientoPerfil = new System.Windows.Forms.TextBox();
            this.panelLinea = new System.Windows.Forms.Panel();
            this.txtGeneroPerfil = new System.Windows.Forms.TextBox();
            this.txtNombreCompletoPerfil = new System.Windows.Forms.TextBox();
            this.txtDNIPerfil = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNombreCompleto = new System.Windows.Forms.Label();
            this.lblArea = new System.Windows.Forms.Label();
            this.lblDNI = new System.Windows.Forms.Label();
            this.pbFotoPerfil = new System.Windows.Forms.PictureBox();
            this.btnEditarPerfil = new System.Windows.Forms.Button();
            this.lblTituloPerfil = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbFotoPerfil)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCorreoPerfil
            // 
            this.txtCorreoPerfil.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreoPerfil.Location = new System.Drawing.Point(384, 312);
            this.txtCorreoPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtCorreoPerfil.Name = "txtCorreoPerfil";
            this.txtCorreoPerfil.ReadOnly = true;
            this.txtCorreoPerfil.Size = new System.Drawing.Size(352, 28);
            this.txtCorreoPerfil.TabIndex = 69;
            this.txtCorreoPerfil.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNombrePerfil
            // 
            this.txtNombrePerfil.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombrePerfil.Location = new System.Drawing.Point(468, 276);
            this.txtNombrePerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtNombrePerfil.Name = "txtNombrePerfil";
            this.txtNombrePerfil.ReadOnly = true;
            this.txtNombrePerfil.Size = new System.Drawing.Size(193, 28);
            this.txtNombrePerfil.TabIndex = 68;
            this.txtNombrePerfil.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDireccionPerfil
            // 
            this.txtDireccionPerfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDireccionPerfil.Location = new System.Drawing.Point(486, 557);
            this.txtDireccionPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtDireccionPerfil.Name = "txtDireccionPerfil";
            this.txtDireccionPerfil.ReadOnly = true;
            this.txtDireccionPerfil.Size = new System.Drawing.Size(425, 26);
            this.txtDireccionPerfil.TabIndex = 67;
            // 
            // txtTelefonoPerfil
            // 
            this.txtTelefonoPerfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefonoPerfil.Location = new System.Drawing.Point(486, 523);
            this.txtTelefonoPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtTelefonoPerfil.Name = "txtTelefonoPerfil";
            this.txtTelefonoPerfil.ReadOnly = true;
            this.txtTelefonoPerfil.Size = new System.Drawing.Size(195, 26);
            this.txtTelefonoPerfil.TabIndex = 66;
            // 
            // txtFechaNacimientoPerfil
            // 
            this.txtFechaNacimientoPerfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFechaNacimientoPerfil.Location = new System.Drawing.Point(486, 489);
            this.txtFechaNacimientoPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtFechaNacimientoPerfil.Name = "txtFechaNacimientoPerfil";
            this.txtFechaNacimientoPerfil.ReadOnly = true;
            this.txtFechaNacimientoPerfil.Size = new System.Drawing.Size(304, 26);
            this.txtFechaNacimientoPerfil.TabIndex = 65;
            // 
            // panelLinea
            // 
            this.panelLinea.Location = new System.Drawing.Point(237, 350);
            this.panelLinea.Name = "panelLinea";
            this.panelLinea.Size = new System.Drawing.Size(706, 21);
            this.panelLinea.TabIndex = 64;
            this.panelLinea.Paint += new System.Windows.Forms.PaintEventHandler(this.panelLinea_Paint);
            // 
            // txtGeneroPerfil
            // 
            this.txtGeneroPerfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGeneroPerfil.Location = new System.Drawing.Point(486, 455);
            this.txtGeneroPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtGeneroPerfil.Name = "txtGeneroPerfil";
            this.txtGeneroPerfil.ReadOnly = true;
            this.txtGeneroPerfil.Size = new System.Drawing.Size(208, 26);
            this.txtGeneroPerfil.TabIndex = 63;
            // 
            // txtNombreCompletoPerfil
            // 
            this.txtNombreCompletoPerfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreCompletoPerfil.Location = new System.Drawing.Point(486, 418);
            this.txtNombreCompletoPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtNombreCompletoPerfil.Name = "txtNombreCompletoPerfil";
            this.txtNombreCompletoPerfil.ReadOnly = true;
            this.txtNombreCompletoPerfil.Size = new System.Drawing.Size(327, 26);
            this.txtNombreCompletoPerfil.TabIndex = 62;
            // 
            // txtDNIPerfil
            // 
            this.txtDNIPerfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDNIPerfil.Location = new System.Drawing.Point(486, 387);
            this.txtDNIPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.txtDNIPerfil.Name = "txtDNIPerfil";
            this.txtDNIPerfil.ReadOnly = true;
            this.txtDNIPerfil.Size = new System.Drawing.Size(145, 26);
            this.txtDNIPerfil.TabIndex = 61;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(375, 559);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 21);
            this.label7.TabIndex = 48;
            this.label7.Text = "Direccion:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(385, 523);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 21);
            this.label6.TabIndex = 47;
            this.label6.Text = "Telefono:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(267, 491);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 21);
            this.label1.TabIndex = 46;
            this.label1.Text = "Fecha de Nacimiento:";
            // 
            // lblNombreCompleto
            // 
            this.lblNombreCompleto.AutoSize = true;
            this.lblNombreCompleto.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreCompleto.Location = new System.Drawing.Point(297, 420);
            this.lblNombreCompleto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombreCompleto.Name = "lblNombreCompleto";
            this.lblNombreCompleto.Size = new System.Drawing.Size(171, 21);
            this.lblNombreCompleto.TabIndex = 0;
            this.lblNombreCompleto.Text = "Nombre Completo:";
            // 
            // lblArea
            // 
            this.lblArea.AutoSize = true;
            this.lblArea.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArea.Location = new System.Drawing.Point(385, 457);
            this.lblArea.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblArea.Name = "lblArea";
            this.lblArea.Size = new System.Drawing.Size(78, 21);
            this.lblArea.TabIndex = 2;
            this.lblArea.Text = "Género:";
            // 
            // lblDNI
            // 
            this.lblDNI.AutoSize = true;
            this.lblDNI.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDNI.Location = new System.Drawing.Point(432, 389);
            this.lblDNI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDNI.Name = "lblDNI";
            this.lblDNI.Size = new System.Drawing.Size(46, 21);
            this.lblDNI.TabIndex = 1;
            this.lblDNI.Text = "DNI:";
            // 
            // pbFotoPerfil
            // 
            this.pbFotoPerfil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFotoPerfil.Location = new System.Drawing.Point(486, 88);
            this.pbFotoPerfil.Margin = new System.Windows.Forms.Padding(4);
            this.pbFotoPerfil.Name = "pbFotoPerfil";
            this.pbFotoPerfil.Size = new System.Drawing.Size(160, 180);
            this.pbFotoPerfil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFotoPerfil.TabIndex = 60;
            this.pbFotoPerfil.TabStop = false;
            this.pbFotoPerfil.Paint += new System.Windows.Forms.PaintEventHandler(this.pbFoto_Paint);
            // 
            // btnEditarPerfil
            // 
            this.btnEditarPerfil.BackColor = System.Drawing.Color.Transparent;
            this.btnEditarPerfil.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarPerfil.Image = global::AstreiaSoft.Properties.Resources.img_editar_17;
            this.btnEditarPerfil.Location = new System.Drawing.Point(962, 34);
            this.btnEditarPerfil.Name = "btnEditarPerfil";
            this.btnEditarPerfil.Size = new System.Drawing.Size(143, 59);
            this.btnEditarPerfil.TabIndex = 72;
            this.btnEditarPerfil.Text = "Editar";
            this.btnEditarPerfil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditarPerfil.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEditarPerfil.UseVisualStyleBackColor = false;
            this.btnEditarPerfil.Click += new System.EventHandler(this.btnEditarAdmin_Click);
            // 
            // lblTituloPerfil
            // 
            this.lblTituloPerfil.AutoSize = true;
            this.lblTituloPerfil.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloPerfil.ForeColor = System.Drawing.Color.DarkCyan;
            this.lblTituloPerfil.Location = new System.Drawing.Point(31, 34);
            this.lblTituloPerfil.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTituloPerfil.Name = "lblTituloPerfil";
            this.lblTituloPerfil.Size = new System.Drawing.Size(85, 37);
            this.lblTituloPerfil.TabIndex = 73;
            this.lblTituloPerfil.Text = "Perfil";
            // 
            // frmPantallaPerfil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1145, 632);
            this.Controls.Add(this.lblTituloPerfil);
            this.Controls.Add(this.txtCorreoPerfil);
            this.Controls.Add(this.btnEditarPerfil);
            this.Controls.Add(this.txtNombrePerfil);
            this.Controls.Add(this.txtDireccionPerfil);
            this.Controls.Add(this.pbFotoPerfil);
            this.Controls.Add(this.txtTelefonoPerfil);
            this.Controls.Add(this.lblDNI);
            this.Controls.Add(this.txtFechaNacimientoPerfil);
            this.Controls.Add(this.lblArea);
            this.Controls.Add(this.panelLinea);
            this.Controls.Add(this.lblNombreCompleto);
            this.Controls.Add(this.txtGeneroPerfil);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNombreCompletoPerfil);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDNIPerfil);
            this.Controls.Add(this.label7);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmPantallaPerfil";
            this.Text = "frmPantallaPerfil";
            ((System.ComponentModel.ISupportInitialize)(this.pbFotoPerfil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblNombreCompleto;
        private System.Windows.Forms.Label lblArea;
        private System.Windows.Forms.Label lblDNI;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbFotoPerfil;
        private System.Windows.Forms.TextBox txtNombreCompletoPerfil;
        private System.Windows.Forms.TextBox txtDNIPerfil;
        private System.Windows.Forms.TextBox txtGeneroPerfil;
        private System.Windows.Forms.TextBox txtDireccionPerfil;
        private System.Windows.Forms.TextBox txtTelefonoPerfil;
        private System.Windows.Forms.TextBox txtFechaNacimientoPerfil;
        private System.Windows.Forms.Panel panelLinea;
        private System.Windows.Forms.TextBox txtNombrePerfil;
        private System.Windows.Forms.TextBox txtCorreoPerfil;
        private System.Windows.Forms.Button btnEditarPerfil;
        private System.Windows.Forms.Label lblTituloPerfil;
    }
}